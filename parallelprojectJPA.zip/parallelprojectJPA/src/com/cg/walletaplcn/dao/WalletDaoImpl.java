package com.cg.walletaplcn.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.walletaplcn.beans.Customer;
import com.cg.walletaplcn.beans.Transaction;
import com.cg.walletaplcn.exception.WalletException;

public class WalletDaoImpl implements WalletDao{

	HashMap<String,Customer> custdb=new HashMap<String,Customer>();
	
	HashMap<String,String> transaction=new HashMap<String,String>();
	public String st="Details\n";

	private String name;

	private String mobileNo;

	private String mailid;
	
	double amount;
	double balance;
	
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=emf.createEntityManager();
	
	@Override
	public Customer createAccount(String mobileNo,Customer c) {
		// TODO Auto-generated method stub
		double balance = 0;
		
		Customer cust=new Customer(mobileNo,mailid,name,balance,amount);
		
		em.getTransaction().begin();
		
		c.setBalance(balance);
		//c.setDepositAmount(amount);
		c.setMailid(c.getMailid());
		c.setMobileNo(c.getMobileNo());
		c.setName(c.getName());
		em.persist(c);
		em.flush();
		em.getTransaction().commit();
		
		return c;
	}

	@Override
	public double showBalance(String mobileNo) throws WalletException{
		// TODO Auto-generated method stub
		
		double balance;
		
	
		if(mobileNo.length()==10)
		{
			
			if(em.find(Customer.class, mobileNo) != null)
			{
				Customer c=em.find(Customer.class, mobileNo);
				balance=c.getBalance();
			}
			else
			{
				throw new WalletException("mobile number doesn't exist in database");
			}
		}
		else
		{
			throw new WalletException("mobile number should be of 10 digits");
		}
		return balance;
	}

	@Override
	public double deposit(String mobileNo, double amount) throws WalletException{
		// TODO Auto-generated method stub
		double balance;
		
		em.getTransaction().begin();
		if(mobileNo.length()==10)
		{
			if(em.find(Customer.class, mobileNo) != null)
			{
				Customer c=em.find(Customer.class, mobileNo);
				Transaction transaction=em.find(Transaction.class, mobileNo);
				if(amount>0)
				{
					balance=c.getBalance()+amount;
					c.setBalance(balance);
					
					em.merge(c);
					em.getTransaction().commit();
					
					String trans="Amount of Rs."+amount+" is deposited";
					
					st=transaction.getMsg()+"\n"+trans;
					em.merge(transaction);
					em.getTransaction().commit();
					//st=transaction.get(mobileNo)+"\n"+trans;
					//transaction.put(mobileNo,st );
					
				}
				else
				{
					throw new WalletException("invalid deposit amount");
				}
			}
			else
			{
				throw new WalletException("mobile number doesn't exist");
			
			}
		}
		else
		{
			throw new WalletException("mobile number should be of 10digits");
		}
		return balance;
	}
		

	@Override
	public double withdraw(String mobileNo, double amount) throws WalletException{
		// TODO Auto-generated method stub
		
		em.getTransaction().begin();
		
		
		if(mobileNo.length()==10)
		{
			if(em.find(Customer.class, mobileNo) != null)
			{
				Customer c=em.find(Customer.class, mobileNo);
				Transaction transaction=em.find(Transaction.class, mobileNo);
				if(c.getBalance()>amount)
				{
					balance=c.getBalance()-amount;
					c.setBalance(balance);
					em.merge(c);
					em.getTransaction().commit();
					String trans="Amount of Rs."+amount+" is withdrawn";
					
					st=transaction.getMsg()+"\n"+trans;
					em.merge(transaction);
					em.getTransaction().commit();
					//st=st+transaction.get(mobileNo);
					//st=transaction.get(mobileNo)+"\n"+trans;
					//transaction.put(mobileNo,st);
				}
				else
				{
					throw new WalletException("insufficient balance");
				}
			}
			else
			{
				throw new WalletException("mobile number doesn't exist in database");
			}
		}
		else
		{
			throw new WalletException("mobile number should be of 10digits");
		}
		return balance;
	}

	@Override
	public int fundTransfer(String mobileNo, String recMobileNo,double amount) throws WalletException
	{

		double bal1,bal2;
		em.getTransaction().begin();
		if(mobileNo.length()==10)
		{
		if(recMobileNo.length()==10)
		{
			if(em.find(Customer.class, mobileNo) != null)
			{
				if(em.find(Customer.class, recMobileNo) != null)
				{
					
					Customer c=em.find(Customer.class, mobileNo);
					Customer c2=em.find(Customer.class, recMobileNo);
					Transaction transaction=em.find(Transaction.class, mobileNo);
					if(c.getBalance()>amount)
					{
					bal1=c.getBalance()-amount;
					c.setBalance(bal1);
					bal2=c2.getBalance()+amount;
					c2.setBalance(bal2);
					em.merge(c);
					em.merge(c2);
					em.getTransaction().commit();
					String trans="Amount of Rs."+amount+" is transferred to "+recMobileNo;
					//st=st+transaction.get(mobileNo);
					st=transaction.getMsg()+"\n"+trans;
					em.merge(transaction);
					em.getTransaction().commit();
					
					//st=transaction.get(mobileNo)+trans;
					//transaction.put(mobileNo,st);
					}
					else
					{
						throw new WalletException("insufficient balance");
					}
				}
				else
				{
					throw new WalletException("receiver mobile number doesn't exist");
				}
			}
			else
			{
				throw new WalletException("sender mobile number doesn't exist");
			}
		}
		
		else
		{
			throw new WalletException("mobile number should be of 10digits");
		}
		}
		else
		{
			throw new WalletException("mobile number should be of 10digits");
		}
	return (int) bal1;
}

	@Override
	public String printTransactions(String mobileNo)
	{
		Transaction transaction=em.find(Transaction.class, mobileNo);
		String st=transaction.getMsg().replaceAll("null","");
		return st;
		
	}
	
				
	}
	
