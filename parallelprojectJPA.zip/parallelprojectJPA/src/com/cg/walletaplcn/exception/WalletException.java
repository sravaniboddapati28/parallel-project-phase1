package com.cg.walletaplcn.exception;

public class WalletException extends Exception
{
	WalletException()
	{
		
	}
	public WalletException(String msg)
	{
		super(msg);
	}
	
}
