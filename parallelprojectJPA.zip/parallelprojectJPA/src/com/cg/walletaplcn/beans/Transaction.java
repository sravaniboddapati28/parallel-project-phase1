package com.cg.walletaplcn.beans;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="transaction")
public class Transaction {

	@Id
	@Column(name="mobile_num")
	String mobileNo;
	@Column(name="msg")
	String msg;
	
	
	public Transaction(String mobileNo2, String trans) {
		// TODO Auto-generated constructor stub
		this.mobileNo=mobileNo2;
		this.msg=trans;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
