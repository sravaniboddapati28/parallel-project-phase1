package com.cg.walletaplcn.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name="customer")
public class Customer {

	@Id
	
	String mobileNo;
	@Column(name="mailid")
	String mailid;
	@Column(name="name")
	String name;
	@Column(name="balance")
	double balance;
	@Column(name="amount")
	double amount;
	
	public Customer()
	{
		
	}
	public Customer(String mobileNo,String mailid,String name,double balance,double amount) {
		
		this.amount=amount;
		this.name=name;
		this.mobileNo = mobileNo;
		this.mailid = mailid;
		this.balance = balance;
		
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public double getDepositAmount() {
		return amount;
	}
	public void setDepositAmount(double amount) {
		this.amount = amount;
	}
	@Id
	@Column(name="mobile_num",unique=true, nullable=false, length=10)
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public double getBalance() {
		return balance;
	}
	public double setBalance(double balance) {
		return this.balance = balance;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name+"\t"+mobileNo+"\t"+mailid+"\t"+balance;
	}
}
