$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/Login.feature");
formatter.feature({
  "name": "LoginFeature",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Accepting the details",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@mytag"
    }
  ]
});
formatter.step({
  "name": "I have login application",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefs.i_have_login_application()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter firstname",
  "rows": [
    {
      "cells": [
        "name"
      ]
    },
    {
      "cells": [
        "abc"
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "StepDefs.i_enter_firstname(DataTable)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "lastname",
  "rows": [
    {
      "cells": [
        "xyz"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "StepDefs.lastname(DataTable)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "select checkbox",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefs.select_checkbox()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "submit",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefs.submit()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "redirect page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefs.redirect_page()"
});
formatter.result({
  "error_message": "java.lang.AssertionError\r\n\tat org.junit.Assert.fail(Assert.java:86)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat org.junit.Assert.assertTrue(Assert.java:52)\r\n\tat StepDefs.redirect_page(StepDefs.java:116)\r\n\tat ✽.redirect page(src/test/resources/Login.feature:13)\r\n",
  "status": "failed"
});
});