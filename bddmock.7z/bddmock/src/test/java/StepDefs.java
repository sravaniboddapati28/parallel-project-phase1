import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import bddmock.Browser;
import bddmock.LoanApplicationPage;
import bddmock.SuccessPage;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.util.Arrays;
import java.util.List;

import org.junit.*;

public class StepDefs {
	WebDriver driver = new ChromeDriver();
	
	private LoanApplicationPage page=new LoanApplicationPage();
	
	private SuccessPage spage=new SuccessPage();
	
	@Given("^I have login application$")
	public void i_have_login_application() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	    
		//System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");
		
		//String pwd=System.getProperty("user.dir");
		//driver.get(pwd+"src\\main\\webapp\\LoanApplicationPage.html");
		
		//driver.get("D:\\training\\10012018-JAVA\\code\\eclipse-workspace\\bddmock\\src\\main\\webapp\\LoanApplicationPage.html");
		page.goTo();
		Assert.assertTrue(page.isAt());
	}

	/*@When("^I enter firstname$")
	public void i_enter_firstname() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		
		//driver.findElement(By.id("firstName")).sendKeys("sravani");
		
		
		String firstName ="abc";
		page.setFirstName(firstName);
		
	    WebElement first=page.getFirstName();
	    System.out.println("first"+page.getFirstName());
	}

	@When("^lastname$")
	public void lastname() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		
	    //driver.findElement(By.id("lastName")).sendKeys("boddapati");
		String lastName="xyz";
		page.setLastName(lastName);
		
	}
*/
	
	@When("^I enter firstname$")
	public void i_enter_firstname(DataTable arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	    //throw new PendingException();
		List<String> ld= arg1.asList(String.class);
		System.out.println(ld.get(1));
		page.setFirstName(ld.get(1));
		
	}

	@When("^lastname$")
	public void lastname(DataTable arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
		List<String> ld= arg1.asList(String.class);
		page.setLastName(ld.get(0));
	    //throw new PendingException();
	}
	@When("^select checkbox$")
	public void select_checkbox() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		
		//driver.findElement(By.name("TermsAcceptance")).click();
		page.acceptTerms();
	}
	@When("^submit$")
	public void submit() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		
		//driver.findElement(By.name("submit")).click();
		page.submit();
		Assert.assertTrue(page.isAt());
	}
	
	@Then("^redirect page$")
	public void redirect_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		spage.goTo();
		Assert.assertTrue(page.isAt());
		Assert.assertEquals(page.getClass(),spage.getFname());
		Assert.assertEquals(page.getLastName(), spage.getSname());
	    page.redirectPage();
	}
	
	/*@After
	public void closefunc()
	{
		Browser.close();
	}
*/

}
