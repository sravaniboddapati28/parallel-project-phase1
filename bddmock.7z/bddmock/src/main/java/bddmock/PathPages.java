package bddmock;

import org.openqa.selenium.By;

public class PathPages {

	static String url = "D:\\training\\10012018-JAVA\\code\\eclipse-workspace\\bddmock\\src\\main\\webapp\\LoanApplicationPage.html";
	static String title = "Loan Application Page";
	static String url2 = "D:\\training\\10012018-JAVA\\code\\eclipse-workspace\\bddmock\\src\\main\\webapp\\successPage.html";
	
	public void goTo() {
		
		Browser.goTo(url);
	}

	public boolean isAt() {
		return Browser.title().equals(title);
	}
	
	public void acceptTerms()
	{
		Browser.driver.findElement(By.name("TermsAcceptance")).click();
	}
	public void submit()
	{
		Browser.driver.findElement(By.name("submit")).click();
	}
	public void redirectPage()
	{
		Browser.redirectPage(url2);
	}

}
