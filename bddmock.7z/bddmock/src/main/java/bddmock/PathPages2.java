package bddmock;

public class PathPages2 {

	static String url2 = "D:\\training\\10012018-JAVA\\code\\eclipse-workspace\\bddmock\\src\\main\\webapp\\successPage.html";
	static String title = "Success page";
	
	public void goTo() {
		
		Browser.goTo(url2);
	}
}
