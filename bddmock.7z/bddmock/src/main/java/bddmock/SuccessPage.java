package bddmock;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SuccessPage extends PathPages2{

	static String url2 = "D:\\training\\10012018-JAVA\\code\\eclipse-workspace\\bddmock\\src\\main\\webapp\\successPage.html";
	static String title = "Success page";
	public SuccessPage()
	{
		PageFactory.initElements(Browser.driver, this);
	}
	
	@FindBy(how=How.ID,id="firstName")
	private WebElement fname;
	
	@FindBy(how=How.ID,id="lastName")
	private WebElement sname;

	public WebElement getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public WebElement getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname.sendKeys(sname);
	}

	public void goTo() {
		// TODO Auto-generated method stub
		Browser.goTo(url2);
	}

	
}
